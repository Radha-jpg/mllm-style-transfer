# PART 1 baseline export

Source notebook: FINAL_DISSERTATION_ROUTING_BASELINES_PART1
Run ID: QUALRUN_20260919T082948Z
Generated: 2026-09-19T09:18:31.814812

## Methods included
- IP-Adapter + rect masks
- IP-Adapter global (no routing)
- Proposed -- Regional Cross-Attention (F)
- Sequential (naive two-pass)

## Samples included
- QUAL_01
- QUAL_02
- QUAL_03

## Known limitations
- Hard compositing was removed because it produced the same outputs as the
  Sequential baseline for all three samples.
- Global IP-Adapter now uses the same checkpoint as F
  (ip-adapter_sd15.bin). An earlier run used ip-adapter-plus_sd15.bin
  and is not included in this export.
- C1 reference-hash cross-verification was not available in this environment.
- This notebook does not compute the descriptive CLIP-based metrics. These
  are produced in Part 2 for all methods.

## Contents
- manifest.json -- one row per (sample, method)
- configs.json -- generation configuration and C1 reference information
- export_package.json -- combined package information
- assets.json + assets/<sample_id>/ -- content images, style references, and masks
- outputs/<sample_id>/<method_slug>.png -- generated images
- README.md -- this file

No model checkpoints are included in this package. The checkpoint names used
by each method are recorded in manifest.json and configs.json.
