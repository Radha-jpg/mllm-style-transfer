# PART 2 baseline export

Source notebook: FINAL_DISSERTATION_ROUTING_BASELINES_PART2
Run ID: QUALRUN_20260919T082948Z
Generated: 2026-09-20T03:16:49.509203

## Methods included
- AdaIN
- ControlNet segmentation
- IP-Adapter + rect masks
- IP-Adapter global (no routing)
- InstructPix2Pix
- MultiDiffusion-style regional noise fusion + IP-Adapter
- NST
- Proposed -- Regional Cross-Attention (F)
- Regional text-attention bias
- SDXL text-only
- Sequential (naive two-pass)

## Samples included
- QUAL_01
- QUAL_02
- QUAL_03

## Not included
- RegionRoute: no official implementation was available.
- MTADiffusion (Huang et al., CVPR 2025): no checkpoint was available. It is a different method
  from the MultiDiffusion-style baseline included here.

## Notes
- Hard compositing was removed as a separate method because its implementation called the
  Sequential baseline and gave byte-identical outputs.
- The Global IP-Adapter baseline uses the same checkpoint as F. An earlier run used
  ip-adapter-plus_sd15.bin and its output is not included.
- SDXL text-only is skipped in this notebook (status='skipped' in manifest.json) because its
  checkpoint did not fit on this machine (CUDA out of memory in one run, disk quota in another).
  It is generated in the BrushEdit notebook with the same settings, see BRUSHEDIT_BASELINE_EXPORT.zip.
- NST and AdaIN generate each region independently and paste it with a hard mask, so their leakage
  and boundary results cannot be compared directly with the jointly generated methods.
- InstructPix2Pix and ControlNet segmentation do not receive the style reference images. The
  ControlNet segmentation map is painted from the masks used in this notebook.
- The regional attention bias uses an IP-Adapter scale of 0. It is a control for the mechanism and
  does not use the style references.
- The style metric uses the IP-Adapter image encoder, which may favour methods conditioned on it
  (F, Sequential, Global, Rectangular and MultiDiffusion-style).
- See configs.json for the status of the C1 reference hash check.

## Contents
- manifest.json: one row per sample and method
- metrics.csv: descriptive CLIP metrics per sample, not averaged
- configs.json: generation config, C1 check status and methods not included
- export_package.json: the same information in one file
- outputs/<sample_id>/<method_slug>.png: generated images
- README.md: this file

No model checkpoints are included, only the checkpoint name used by each method.
