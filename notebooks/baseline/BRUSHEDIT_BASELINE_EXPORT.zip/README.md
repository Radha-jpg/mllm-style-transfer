# BrushEdit baseline export

Source notebook: BrushEdit_for_dissertation
Samples included: ['QUAL_01', 'QUAL_02', 'QUAL_03']

## What this baseline is, and is not
BrushEdit receives the same content images, masks, and per-region text prompts as
every other baseline. It does NOT receive the two style-reference paintings -- there
is no image-reference conditioning in this setup, only text. It runs on a different
backbone/checkpoint (BrushNetX + DreamShaper 8) and restores the unmasked region with
a pixel-exact blended paste after each step. It is a secondary architectural
comparator, not an equal-information baseline against F.

## Known limitations
- No style-reference images supplied (by design, not an oversight).
- SDXL text-only (if present) is a text-only conditioning control: no style references, one joint
  prompt over the union mask, pipeline-default strength.
- Different backbone/checkpoint from every IP-Adapter-based method.
- Blended restoration structurally limits how much a leakage/containment metric can
  penalise this method, for the same reason it does for NST/AdaIN in Part 2.
- This notebook does not compute the descriptive CLIP metrics; those are computed in
  Part 2 once BrushEdit's images are merged in via brushedit_results.json.

## Contents
- manifest.json -- one row per (sample, method): BrushEdit, plus SDXL text-only when RUN_SDXL
- configs.json -- BrushEdit's own generation defaults
- export_package.json -- the same information as a single nested document
- outputs/<sample_id>/BrushEdit.png -- generated images
- README.md -- this file

Note: brushedit_results.json and provenance.csv (written by the previous cell, at
/content/drive/MyDrive/baselines) are kept exactly as before -- Part 2 reads those directly and does
not use this package.

No model checkpoints are included in this package -- only the checkpoint name used.
